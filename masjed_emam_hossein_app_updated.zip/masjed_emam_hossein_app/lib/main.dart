import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MasjedApp());
}

class MasjedApp extends StatelessWidget {
  const MasjedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مسجد امام حسین (ع)',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        fontFamily: null,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  final List<_MenuItem> items = const [
    _MenuItem('اطلاعیه‌ها', Icons.campaign_outlined),
    _MenuItem('برنامه مراسم‌ها', Icons.calendar_month_outlined),
    _MenuItem('اعضای مسجد', Icons.groups_outlined),
    _MenuItem('حضور و غیاب', Icons.fact_check_outlined),
    _MenuItem('مسابقات فرهنگی', Icons.emoji_events_outlined),
    _MenuItem('گالری تصاویر', Icons.photo_library_outlined),
    _MenuItem('ارتباط با مسجد', Icons.call_outlined),
    _MenuItem('مدیریت', Icons.admin_panel_settings_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text('مسجد امام حسین (ع)'),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Image.asset(
                    'assets/images/masjed.jpg',
                    height: 240,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    color: Colors.black54,
                    child: const Column(
                      children: [
                        Text(
                          'مسجد امام حسین (ع)',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'کوی ابوذرغفاری',
                          style: TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'دسترسی سریع',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1.25,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemBuilder: (context, index) {
                final item = items[index];
                return Card(
                  elevation: 2,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => item.title == 'اطلاعیه‌ها'
                              ? const AnnouncementsPage()
                              : SectionPage(title: item.title, icon: item.icon),
                        ),
                      );
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(item.icon, size: 38),
                        const SizedBox(height: 10),
                        Text(
                          item.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class SectionPage extends StatelessWidget {
  final String title;
  final IconData icon;

  const SectionPage({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 70),
                const SizedBox(height: 20),
                Text(
                  'بخش $title',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                const Text(
                  'این بخش در مرحله بعدی به امکانات واقعی و ذخیره اطلاعات متصل می‌شود.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MenuItem {
  final String title;
  final IconData icon;
  const _MenuItem(this.title, this.icon);
}


class Announcement {
  final String title;
  final String text;
  final String date;

  const Announcement({
    required this.title,
    required this.text,
    required this.date,
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'text': text,
        'date': date,
      };

  factory Announcement.fromJson(Map<String, dynamic> json) {
    return Announcement(
      title: json['title'] as String? ?? '',
      text: json['text'] as String? ?? '',
      date: json['date'] as String? ?? '',
    );
  }
}

class AnnouncementsPage extends StatefulWidget {
  const AnnouncementsPage({super.key});

  @override
  State<AnnouncementsPage> createState() => _AnnouncementsPageState();
}

class _AnnouncementsPageState extends State<AnnouncementsPage> {
  static const _storageKey = 'mosque_announcements';
  List<Announcement> announcements = [];

  @override
  void initState() {
    super.initState();
    _loadAnnouncements();
  }

  Future<void> _loadAnnouncements() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList(_storageKey) ?? [];
    setState(() {
      announcements = saved
          .map((item) => Announcement.fromJson(jsonDecode(item)))
          .toList();
    });
  }

  Future<void> _saveAnnouncements() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _storageKey,
      announcements.map((item) => jsonEncode(item.toJson())).toList(),
    );
  }

  Future<void> _addAnnouncement() async {
    final titleController = TextEditingController();
    final textController = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('اطلاعیه جدید'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: 'عنوان اطلاعیه',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: textController,
                    maxLines: 5,
                    decoration: const InputDecoration(
                      labelText: 'متن اطلاعیه',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('انصراف'),
              ),
              FilledButton(
                onPressed: () {
                  if (titleController.text.trim().isEmpty ||
                      textController.text.trim().isEmpty) {
                    return;
                  }
                  Navigator.pop(dialogContext, true);
                },
                child: const Text('ثبت'),
              ),
            ],
          ),
        );
      },
    );

    if (result == true) {
      final now = DateTime.now();
      final date = '${now.year}/${now.month.toString().padLeft(2, '0')}/${now.day.toString().padLeft(2, '0')}';
      setState(() {
        announcements.insert(
          0,
          Announcement(
            title: titleController.text.trim(),
            text: textController.text.trim(),
            date: date,
          ),
        );
      });
      await _saveAnnouncements();
    }

    titleController.dispose();
    textController.dispose();
  }

  Future<void> _deleteAnnouncement(int index) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('حذف اطلاعیه'),
          content: const Text('آیا از حذف این اطلاعیه مطمئن هستید؟'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('خیر'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('بله، حذف شود'),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      setState(() => announcements.removeAt(index));
      await _saveAnnouncements();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('اطلاعیه‌ها'),
          centerTitle: true,
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _addAnnouncement,
          icon: const Icon(Icons.add),
          label: const Text('اطلاعیه جدید'),
        ),
        body: announcements.isEmpty
            ? const Center(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'هنوز اطلاعیه‌ای ثبت نشده است.\n\nبرای افزودن اطلاعیه، دکمه «اطلاعیه جدید» را بزنید.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 17),
                  ),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: announcements.length,
                itemBuilder: (context, index) {
                  final item = announcements[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.campaign_outlined, size: 28),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  item.title,
                                  style: const TextStyle(
                                    fontSize: 19,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              IconButton(
                                tooltip: 'حذف',
                                onPressed: () => _deleteAnnouncement(index),
                                icon: const Icon(Icons.delete_outline),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(item.text, style: const TextStyle(fontSize: 16)),
                          const SizedBox(height: 10),
                          Text(
                            'تاریخ: ${item.date}',
                            style: TextStyle(
                              fontSize: 13,
                              color: Theme.of(context).colorScheme.outline,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
