import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MasjedApp());
}

class MasjedApp extends StatelessWidget {
  const MasjedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مسجد امام حسین (ع)',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        appBarTheme: const AppBarTheme(centerTitle: true),
      ),
      home: const HomePage(),
    );
  }
}

class Member {
  String name;
  String phone;
  bool present;
  Member({required this.name, required this.phone, this.present = false});

  Map<String, dynamic> toJson() =>
      {'name': name, 'phone': phone, 'present': present};

  factory Member.fromJson(Map<String, dynamic> j) =>
      Member(name: j['name'], phone: j['phone'], present: j['present'] ?? false);
}

class Announcement {
  String title;
  String text;
  String date;
  Announcement(this.title, this.text, this.date);

  Map<String, dynamic> toJson() =>
      {'title': title, 'text': text, 'date': date};

  factory Announcement.fromJson(Map<String, dynamic> j) =>
      Announcement(j['title'], j['text'], j['date']);
}

class MosqueStore extends ChangeNotifier {
  final List<Member> members = [];
  final List<Announcement> announcements = [];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final memberData = p.getString('members');
    final announcementData = p.getString('announcements');

    if (memberData != null) {
      members
        ..clear()
        ..addAll((jsonDecode(memberData) as List)
            .map((e) => Member.fromJson(Map<String, dynamic>.from(e))));
    }
    if (announcementData != null) {
      announcements
        ..clear()
        ..addAll((jsonDecode(announcementData) as List)
            .map((e) => Announcement.fromJson(Map<String, dynamic>.from(e))));
    }

    if (announcements.isEmpty) {
      announcements.add(
        Announcement(
          'به اپلیکیشن مسجد خوش آمدید',
          'اطلاعیه‌ها و برنامه‌های فرهنگی مسجد از این بخش اعلام می‌شود.',
          'امروز',
        ),
      );
      await _saveAnnouncements();
    }
    notifyListeners();
  }

  Future<void> _saveMembers() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('members', jsonEncode(members.map((e) => e.toJson()).toList()));
  }

  Future<void> _saveAnnouncements() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('announcements',
        jsonEncode(announcements.map((e) => e.toJson()).toList()));
  }

  Future<void> addMember(String name, String phone) async {
    members.add(Member(name: name, phone: phone));
    await _saveMembers();
    notifyListeners();
  }

  Future<void> removeMember(int index) async {
    members.removeAt(index);
    await _saveMembers();
    notifyListeners();
  }

  Future<void> toggleAttendance(int index) async {
    members[index].present = !members[index].present;
    await _saveMembers();
    notifyListeners();
  }

  Future<void> addAnnouncement(String title, String text) async {
    final now = DateTime.now();
    final date = '${now.year}/${now.month.toString().padLeft(2, '0')}/${now.day.toString().padLeft(2, '0')}';
    announcements.insert(0, Announcement(title, text, date));
    await _saveAnnouncements();
    notifyListeners();
  }
}

final store = MosqueStore();

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    store.load().then((_) {
      if (mounted) setState(() => loaded = true);
    });
    store.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    store.removeListener(_refresh);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) {
      return const Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }

    final items = [
      ['اطلاعیه‌ها', Icons.campaign_outlined, const AnnouncementsPage()],
      ['برنامه مراسم‌ها', Icons.calendar_month_outlined, const EventsPage()],
      ['اعضای مسجد', Icons.groups_outlined, const MembersPage()],
      ['حضور و غیاب', Icons.fact_check_outlined, const AttendancePage()],
      ['مسابقات فرهنگی', Icons.emoji_events_outlined, const QuizPage()],
      ['گالری تصاویر', Icons.photo_library_outlined, const GalleryPage()],
      ['ارتباط با مسجد', Icons.call_outlined, const ContactPage()],
      ['مدیریت مسجد', Icons.admin_panel_settings_outlined, const AdminPage()],
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('مسجد امام حسین (ع)'),
          actions: [
            IconButton(
              icon: const Icon(Icons.notifications_outlined),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AnnouncementsPage()),
              ),
            )
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Image.asset('assets/images/masjed.jpg',
                      height: 250, width: double.infinity, fit: BoxFit.cover),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    color: Colors.black54,
                    child: const Column(children: [
                      Text('مسجد امام حسین (ع)',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold)),
                      SizedBox(height: 5),
                      Text('کوی ابوذرغفاری',
                          style: TextStyle(color: Colors.white)),
                      SizedBox(height: 5),
                      Text('کانون فرهنگی هنری سالارشهیدان',
                          style: TextStyle(color: Colors.white70)),
                    ]),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: ListTile(
                leading: const Icon(Icons.people),
                title: const Text('تعداد اعضای ثبت‌شده'),
                trailing: Text('${store.members.length} نفر',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 12),
            const Text('بخش‌های اپلیکیشن',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1.18,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemBuilder: (context, i) => Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => items[i][2] as Widget),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(items[i][1] as IconData, size: 40),
                      const SizedBox(height: 10),
                      Text(items[i][0] as String,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AppPage extends StatelessWidget {
  final String title;
  final Widget body;
  const AppPage({super.key, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(appBar: AppBar(title: Text(title)), body: body),
  );
}

class AnnouncementsPage extends StatelessWidget {
  const AnnouncementsPage({super.key});
  @override
  Widget build(BuildContext context) => AppPage(
    title: 'اطلاعیه‌ها',
    body: ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: store.announcements.length,
      itemBuilder: (_, i) {
        final a = store.announcements[i];
        return Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.campaign)),
            title: Text(a.title),
            subtitle: Text('${a.text}\n${a.date}'),
            isThreeLine: true,
          ),
        );
      },
    ),
  );
}

class EventsPage extends StatelessWidget {
  const EventsPage({super.key});
  @override
  Widget build(BuildContext context) => const AppPage(
    title: 'برنامه مراسم‌ها',
    body: Padding(
      padding: EdgeInsets.all(18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Card(child: ListTile(
          leading: Icon(Icons.mosque),
          title: Text('برنامه‌های مسجد'),
          subtitle: Text('مراسم‌ها و برنامه‌های آینده از طریق پنل مدیریت اضافه می‌شوند.'),
        )),
      ]),
    ),
  );
}

class MembersPage extends StatefulWidget {
  const MembersPage({super.key});
  @override
  State<MembersPage> createState() => _MembersPageState();
}

class _MembersPageState extends State<MembersPage> {
  final name = TextEditingController();
  final phone = TextEditingController();

  void add() async {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty) return;
    await store.addMember(name.text.trim(), phone.text.trim());
    name.clear(); phone.clear();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'اعضای مسجد',
    body: Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(controller: name, decoration: const InputDecoration(
            labelText: 'نام و نام خانوادگی', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: phone, keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'شماره موبایل',
              border: OutlineInputBorder())),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity,
            child: FilledButton.icon(onPressed: add,
              icon: const Icon(Icons.person_add), label: const Text('ثبت عضو جدید'))),
        ]),
      ),
      Expanded(
        child: ListView.builder(
          itemCount: store.members.length,
          itemBuilder: (_, i) {
            final m = store.members[i];
            return ListTile(
              leading: CircleAvatar(child: Text('${i + 1}')),
              title: Text(m.name),
              subtitle: Text(m.phone),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  await store.removeMember(i);
                  if (mounted) setState(() {});
                },
              ),
            );
          },
        ),
      ),
    ]),
  );
}

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key});
  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  @override
  Widget build(BuildContext context) {
    final present = store.members.where((m) => m.present).length;
    return AppPage(
      title: 'حضور و غیاب',
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Card(child: ListTile(
            leading: const Icon(Icons.check_circle_outline),
            title: const Text('گزارش امروز'),
            subtitle: Text('حاضر: $present نفر از ${store.members.length} عضو'),
          )),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: store.members.length,
            itemBuilder: (_, i) {
              final m = store.members[i];
              return CheckboxListTile(
                value: m.present,
                title: Text(m.name),
                subtitle: Text(m.phone),
                onChanged: (_) async {
                  await store.toggleAttendance(i);
                  if (mounted) setState(() {});
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});
  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final title = TextEditingController();
  final text = TextEditingController();

  void publish() async {
    if (title.text.trim().isEmpty || text.text.trim().isEmpty) return;
    await store.addAnnouncement(title.text.trim(), text.text.trim());
    title.clear(); text.clear();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اطلاعیه با موفقیت ثبت شد')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => AppPage(
    title: 'مدیریت مسجد',
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('ثبت اطلاعیه جدید',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      TextField(controller: title,
          decoration: const InputDecoration(labelText: 'عنوان اطلاعیه',
              border: OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: text, minLines: 3, maxLines: 5,
          decoration: const InputDecoration(labelText: 'متن اطلاعیه',
              border: OutlineInputBorder())),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: publish, icon: const Icon(Icons.publish),
          label: const Text('انتشار اطلاعیه')),
      const SizedBox(height: 20),
      const Divider(),
      const ListTile(
        leading: Icon(Icons.sms_outlined),
        title: Text('ارسال پیامک'),
        subtitle: Text('در نسخه بعدی به سامانه پیامکی واقعی متصل می‌شود.'),
      ),
      const ListTile(
        leading: Icon(Icons.cloud_outlined),
        title: Text('اتصال آنلاین'),
        subtitle: Text('در نسخه بعدی برای همگام‌سازی چند گوشی اضافه می‌شود.'),
      ),
    ]),
  );
}

class QuizPage extends StatelessWidget {
  const QuizPage({super.key});
  @override
  Widget build(BuildContext context) => const AppPage(
    title: 'مسابقات فرهنگی',
    body: Center(child: Text('بخش مسابقات فرهنگی آماده توسعه است.')),
  );
}

class GalleryPage extends StatelessWidget {
  const GalleryPage({super.key});
  @override
  Widget build(BuildContext context) => AppPage(
    title: 'گالری تصاویر',
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Image.asset('assets/images/masjed.jpg', fit: BoxFit.cover),
      ),
    ),
  );
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});
  @override
  Widget build(BuildContext context) => const AppPage(
    title: 'ارتباط با مسجد',
    body: Padding(
      padding: EdgeInsets.all(18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Card(child: ListTile(
          leading: Icon(Icons.mosque),
          title: Text('مسجد امام حسین (ع)'),
          subtitle: Text('کوی ابوذرغفاری'),
        )),
        Card(child: ListTile(
          leading: Icon(Icons.info_outline),
          title: Text('اطلاعات تماس'),
          subtitle: Text('شماره تماس مسجد از پنل مدیریت قابل ثبت است.'),
        )),
      ]),
    ),
  );
}
